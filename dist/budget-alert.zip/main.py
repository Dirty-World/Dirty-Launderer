def main(event, context): return 'OK', 200
